# Orasal website (orasal.in)

Plain static site (HTML + CSS + vanilla JS). No framework, no build step, no dependencies, no environment variables.

## Deploy on Vercel
- Framework Preset: **Other**
- Build Command: *(leave empty)*   Install Command: *(leave empty)*
- Output Directory: *(leave empty / project root)*
- Make sure `index.html` and `vercel.json` sit at the root of the repo/upload.
- Domains: add both `orasal.in` and `www.orasal.in` to the project. `vercel.json` 308-redirects `www.orasal.in` to `https://orasal.in` (canonical).

## Structure
- `index.html` - home page (styles/scripts inlined)
- `pages/*.html` - inner pages (served at `/pages/<name>.html`; short aliases such as `/about` and `/contact` redirect to them)
- `assets/` - logo, favicon, OG image, founder photos, shared CSS/JS
- `404.html`, `robots.txt`, `sitemap.xml`, `llms.txt`, `favicon.ico`, `vercel.json`

## Contact form
Posts to FormSubmit (`formsubmit.co/ajax/hello.orasal@gmail.com`). On the first real submission FormSubmit emails an activation link to that inbox - click it once. If the request fails, the form shows email/WhatsApp fallback links.

## After deploy
Submit `https://orasal.in/sitemap.xml` in Google Search Console and Bing Webmaster Tools.
