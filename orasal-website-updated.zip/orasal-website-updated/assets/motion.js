/* ==========================================================
   ORASAL — Motion layer (JS)
   Dependency-free spring physics that reproduces the feel of
   Framer Motion / Motion One (springy hover, press, menu) and
   Rive-style reactive vectors (cursor-tracking SVG mascot).
   No network, no build step. Respects prefers-reduced-motion.
   ========================================================== */
(function () {
  'use strict';
  return;
  var fine = window.matchMedia && matchMedia('(hover: hover) and (pointer: fine)').matches;

  /* ---------- spring engine ---------- */
  var active = [], dirty = [], raf = 0, last = 0;
  function frame(t) {
    var dt = Math.min((t - last) / 1000, 1 / 30); last = t;
    for (var i = active.length - 1; i >= 0; i--) { active[i].step(dt); if (active[i].done) active.splice(i, 1); }
    for (var j = 0; j < dirty.length; j++) { dirty[j].apply(); dirty[j].q = false; }
    dirty.length = 0;
    raf = active.length ? requestAnimationFrame(frame) : 0;
  }
  function Spring(v, cfg, owner) { this.v = v; this.t = v; this.vel = 0; this.k = cfg.k; this.c = cfg.c; this.done = true; this.o = owner; }
  Spring.prototype.to = function (t) {
    this.t = t;
    if (this.done) { this.done = false; active.push(this); if (!raf) { last = performance.now(); raf = requestAnimationFrame(frame); } }
  };
  Spring.prototype.jump = function (v) { this.v = v; this.t = v; this.vel = 0; };
  Spring.prototype.step = function (dt) {
    var n = Math.max(1, Math.ceil(dt / 0.008)), h = dt / n;
    for (var i = 0; i < n; i++) { var a = -this.k * (this.v - this.t) - this.c * this.vel; this.vel += a * h; this.v += this.vel * h; }
    if (Math.abs(this.vel) < 0.02 && Math.abs(this.v - this.t) < 0.002) { this.v = this.t; this.vel = 0; this.done = true; }
    if (!this.o.q) { this.o.q = true; dirty.push(this.o); }
  };

  var SNAP = { k: 260, c: 22 }, BOUNCE = { k: 380, c: 17 }, MENU = { k: 300, c: 24 };
  function r2(n) { return Math.round(n * 100) / 100; }

  /* ---------- element motion (x, y, scale, tilt, rotate, opacity) ---------- */
  function Mo(el, cfg, useOp) {
    cfg = cfg || SNAP; this.el = el; this.q = false; this.useOp = !!useOp;
    this.x = new Spring(0, cfg, this); this.y = new Spring(0, cfg, this); this.s = new Spring(1, cfg, this);
    this.rx = new Spring(0, cfg, this); this.ry = new Spring(0, cfg, this); this.rot = new Spring(0, cfg, this);
    this.o = new Spring(1, { k: 200, c: 26 }, this);
  }
  Mo.prototype.go = function (p) { for (var k in p) if (this[k]) this[k].to(p[k]); };
  Mo.prototype.set = function (p) { for (var k in p) if (this[k]) this[k].jump(p[k]); this.apply(); };
  Mo.prototype.apply = function () {
    var e = this.el, rest = this.x.done && this.y.done && this.s.done && this.rx.done && this.ry.done && this.rot.done &&
      this.x.v === 0 && this.y.v === 0 && this.s.v === 1 && this.rx.v === 0 && this.ry.v === 0 && this.rot.v === 0;
    e.style.transform = rest ? '' :
      'perspective(900px) translate3d(' + r2(this.x.v) + 'px,' + r2(this.y.v) + 'px,0) rotateX(' + r2(this.rx.v) +
      'deg) rotateY(' + r2(this.ry.v) + 'deg) rotate(' + r2(this.rot.v) + 'deg) scale(' + r2(this.s.v) + ')';
    if (this.useOp) e.style.opacity = Math.min(1, Math.max(0, this.o.v));
  };
  Mo.prototype.reset = function () {
    this.x.jump(0); this.y.jump(0); this.s.jump(1); this.rx.jump(0); this.ry.jump(0); this.rot.jump(0); this.o.jump(1);
    this.el.style.transform = ''; if (this.useOp) this.el.style.opacity = '';
  };

  /* Elements that use the site's scroll-reveal (.fu) hand over to springs once revealed */
  function ready(el, cb) {
    var cl = el.classList, isFu = cl.contains('fu') || cl.contains('fu-left') || cl.contains('fu-scale');
    function go() { cl.remove('fu', 'fu-left', 'fu-scale', 'd1', 'd2', 'd3', 'd4', 'd5'); cl.add('mo-ready'); cb(); }
    if (!isFu) { cl.add('mo-ready'); cb(); return; }
    if (cl.contains('vis')) { setTimeout(go, 1200); return; }
    var ob = new MutationObserver(function () {
      if (cl.contains('vis')) { ob.disconnect(); setTimeout(go, 1300); }
    });
    ob.observe(el, { attributes: true, attributeFilter: ['class'] });
  }

  /* ---------- cards: lift + 3D tilt + cursor glow + icon pop ---------- */
  function initCard(el, tilt) {
    ready(el, function () {
      var m = new Mo(el, SNAP), hover = false, icons = [];
      if (getComputedStyle(el).position === 'static') el.style.position = 'relative';
      if (tilt) { var g = document.createElement('div'); g.className = 'mo-glow'; g.setAttribute('aria-hidden', 'true'); el.insertBefore(g, el.firstChild); }
      [].forEach.call(el.querySelectorAll('.sicon,.wbfic,.ctico,.procnum'), function (ic) {
        ic.classList.add('mo-ready'); icons.push(new Mo(ic, BOUNCE));
      });
      if (fine) {
        el.addEventListener('pointerenter', function (e) {
          if (e.pointerType !== 'mouse') return; hover = true; el.classList.add('mo-hover');
          m.go({ y: -8, s: 1.015 }); icons.forEach(function (i) { i.go({ s: 1.16, rot: -7 }); });
        });
        el.addEventListener('pointermove', function (e) {
          if (e.pointerType !== 'mouse') return;
          var b = el.getBoundingClientRect(), px = (e.clientX - b.left) / b.width, py = (e.clientY - b.top) / b.height;
          el.style.setProperty('--mx', (px * 100).toFixed(1) + '%'); el.style.setProperty('--my', (py * 100).toFixed(1) + '%');
          if (tilt) m.go({ ry: (px - .5) * 9, rx: -(py - .5) * 9 });
        });
        el.addEventListener('pointerleave', function () {
          hover = false; el.classList.remove('mo-hover');
          m.go({ x: 0, y: 0, s: 1, rx: 0, ry: 0 }); icons.forEach(function (i) { i.go({ s: 1, rot: 0 }); });
        });
      }
      el.addEventListener('pointerdown', function () { m.go({ s: .982 }); });
      ['pointerup', 'pointercancel'].forEach(function (ev) {
        el.addEventListener(ev, function () { m.go({ s: hover ? 1.015 : 1 }); });
      });
    });
  }

  /* ---------- buttons: magnetic pull + springy press ---------- */
  function initBtn(el) {
    if (el.closest('#mmenu')) return;
    ready(el, function () {
      if (getComputedStyle(el).display === 'inline') el.style.display = 'inline-block';
      var m = new Mo(el, BOUNCE), hover = false;
      if (fine) {
        el.addEventListener('pointerenter', function (e) { if (e.pointerType === 'mouse') { hover = true; m.go({ s: 1.06 }); } });
        el.addEventListener('pointermove', function (e) {
          if (e.pointerType !== 'mouse') return;
          var b = el.getBoundingClientRect();
          m.go({ x: ((e.clientX - b.left) / b.width - .5) * 12, y: ((e.clientY - b.top) / b.height - .5) * 9 });
        });
        el.addEventListener('pointerleave', function () { hover = false; m.go({ x: 0, y: 0, s: 1 }); });
      }
      el.addEventListener('pointerdown', function () { m.go({ s: .93 }); });
      ['pointerup', 'pointercancel'].forEach(function (ev) {
        el.addEventListener(ev, function () { m.go({ s: hover ? 1.06 : 1 }); });
      });
    });
  }

  /* ---------- desktop nav: springy sliding pill ---------- */
  function initNav() {
    var ul = document.querySelector('.nlinks'); if (!ul || !fine) return;
    var pill = document.createElement('span'); pill.className = 'mo-pill'; pill.setAttribute('aria-hidden', 'true');
    ul.insertBefore(pill, ul.firstChild);
    var P = { q: false };
    P.x = new Spring(0, SNAP, P); P.w = new Spring(0, SNAP, P); P.o = new Spring(0, { k: 200, c: 26 }, P);
    P.apply = function () {
      pill.style.transform = 'translate3d(' + r2(P.x.v) + 'px,0,0)';
      pill.style.width = Math.max(0, r2(P.w.v)) + 'px';
      pill.style.opacity = Math.min(1, Math.max(0, P.o.v));
    };
    function to(a) {
      var u = ul.getBoundingClientRect(), b = a.getBoundingClientRect();
      pill.style.top = (b.top - u.top) + 'px'; pill.style.height = b.height + 'px';
      if (P.o.v < .05) { P.x.jump(b.left - u.left); P.w.jump(b.width); P.apply(); }
      P.x.to(b.left - u.left); P.w.to(b.width); P.o.to(1);
    }
    [].forEach.call(ul.querySelectorAll('a'), function (a) {
      a.addEventListener('pointerenter', function () { to(a); });
      a.addEventListener('focus', function () { to(a); });
    });
    ul.addEventListener('pointerleave', function () { P.o.to(0); });
    ul.addEventListener('focusout', function () { P.o.to(0); });
  }

  /* ---------- mobile menu: springy panel + staggered items ---------- */
  function initMenu() {
    var mm = document.getElementById('mmenu'); if (!mm) return;
    var panel = new Mo(mm, MENU, true), items = [].map.call(mm.children, function (c) { return new Mo(c, MENU, true); });
    var timers = [];
    function open() {
      timers.forEach(clearTimeout); timers = [];
      panel.set({ y: -18, o: 0 }); panel.go({ y: 0, o: 1 });
      items.forEach(function (it, i) {
        it.set({ y: 26, o: 0 });
        timers.push(setTimeout(function () { it.go({ y: 0, o: 1 }); }, 50 + i * 45));
      });
    }
    function close() { timers.forEach(clearTimeout); timers = []; panel.reset(); items.forEach(function (i) { i.reset(); }); }
    var was = mm.classList.contains('op');
    new MutationObserver(function () {
      var now = mm.classList.contains('op'); if (now === was) return; was = now; now ? open() : close();
    }).observe(mm, { attributes: true, attributeFilter: ['class'] });
  }

  function init() {
    [].forEach.call(document.querySelectorAll('.scard,.wkcard,.pcard,.proccard,.statcard'), function (el) { initCard(el, true); });
    [].forEach.call(document.querySelectorAll('.fcard,.wbf,.wbcm'), function (el) { initCard(el, false); });
    [].forEach.call(document.querySelectorAll('.pbtn,.obtn,.socbtn'), initBtn);
    initNav(); initMenu();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
