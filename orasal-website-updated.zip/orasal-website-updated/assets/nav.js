/* Orasal navbar controller: scroll-spy, active page state, accessible mobile menu.
   Works alongside the existing hamburger code; safe on every page. */
(function () {
  'use strict';
  var nb = document.getElementById('nb'); if (!nb) return;
  var hb = document.getElementById('hbtn'), mm = document.getElementById('mmenu');

  /* Inner pages ship a hamburger but no menu: build it from the desktop links */
  if (hb && !mm) {
    mm = document.createElement('nav'); mm.id = 'mmenu'; mm.setAttribute('aria-label', 'Mobile navigation');
    [].forEach.call(nb.querySelectorAll('.nlinks a'), function (src) {
      var a = document.createElement('a'); a.href = src.getAttribute('href'); a.textContent = src.textContent.trim();
      if (src.hasAttribute('data-founders')) a.setAttribute('data-founders', '1');
      mm.appendChild(a);
    });
    var row = document.createElement('div'); row.className = 'mob-theme-row';
    row.innerHTML = '<span class="theme-label" id="thLblMob">Dark Mode</span>' +
      '<button class="theme-toggle" id="thToggleMob" aria-label="Toggle theme"><div class="theme-toggle-knob">' +
      '<span class="theme-toggle-icon-dark">\ud83c\udf19</span><span class="theme-toggle-icon-light">\u2600\ufe0f</span></div></button>';
    mm.appendChild(row);
    nb.parentNode.insertBefore(mm, nb.nextSibling);
  }
  var root = document.documentElement, desktopMQ = window.matchMedia('(min-width: 901px)');

  /* 1. Real navbar height -> CSS variable (anchor offset + mobile menu top) */
  function setH() { root.style.setProperty('--nav-h', nb.offsetHeight + 'px'); }
  setH(); window.addEventListener('resize', setH); window.addEventListener('load', setH);
  function navH() { return nb.offsetHeight || 72; }

  /* 2. Accessible mobile menu */
  function isOpen() { return !!(mm && mm.classList.contains('op')); }
  if (hb && mm) {
    hb.setAttribute('aria-controls', 'mmenu');
    if (!mm.getAttribute('aria-label')) mm.setAttribute('aria-label', 'Mobile navigation');

    /* Add the missing primary call-to-action to the mobile menu */
    var desktopCta = nb.querySelector('.nright .pbtn');
    if (desktopCta && !mm.querySelector('.pbtn')) {
      var cta = document.createElement('a');
      cta.className = 'pbtn mm-cta'; cta.href = desktopCta.getAttribute('href') || '#ct';
      cta.textContent = desktopCta.textContent.trim() || 'Get Started';
      var row = mm.querySelector('.mob-theme-row');
      row ? mm.insertBefore(cta, row) : mm.appendChild(cta);
    }

    /* Any link inside the menu closes it (also covers the CTA added above) */
    mm.addEventListener('click', function (e) {
      if (e.target.closest('a') && isOpen()) hb.click();
    });

    /* Move focus in when opened; restore it to the button when closed */
    var wasOpen = false, viaKeyboard = false;
    new MutationObserver(function () {
      var o = isOpen();
      if (o && !wasOpen) { var first = mm.querySelector('a'); if (first && viaKeyboard) first.focus(); }
      if (!o && wasOpen && viaKeyboard) hb.focus();
      wasOpen = o;
    }).observe(mm, { attributes: true, attributeFilter: ['class'] });
    hb.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') viaKeyboard = true; });
    hb.addEventListener('pointerdown', function () { viaKeyboard = false; });

    document.addEventListener('keydown', function (e) {
      if (!isOpen()) return;
      if (e.key === 'Escape') { viaKeyboard = true; return; }   /* existing handler closes it */
      if (e.key !== 'Tab') return;
      var f = [hb].concat([].slice.call(mm.querySelectorAll('a[href],button:not([disabled])')));
      var i = f.indexOf(document.activeElement);
      if (e.shiftKey && (i <= 0)) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && (i === f.length - 1)) { e.preventDefault(); f[0].focus(); }
    });

    /* Rotating a tablet / resizing must never leave the page scroll-locked */
    function onMQ() { if (desktopMQ.matches && isOpen()) hb.click(); }
    desktopMQ.addEventListener ? desktopMQ.addEventListener('change', onMQ) : desktopMQ.addListener(onMQ);
  }

  /* 3. Theme toggle: meaningful, live labels for assistive tech */
  function themeLabels() {
    var dark = root.getAttribute('data-theme') !== 'light';
    var text = dark ? 'Switch to light mode' : 'Switch to dark mode';
    ['thToggle', 'thToggleMob'].forEach(function (id) {
      var b = document.getElementById(id); if (!b) return;
      b.setAttribute('aria-label', text); b.setAttribute('title', text); b.setAttribute('aria-pressed', dark ? 'false' : 'true');
    });
  }
  themeLabels();
  new MutationObserver(themeLabels).observe(root, { attributes: true, attributeFilter: ['data-theme'] });

  /* 4. Active link state: scroll-spy for on-page anchors, aria-current for real pages */
  var links = [].slice.call(document.querySelectorAll('.nlinks a, #mmenu a:not(.mm-cta)'));
  var spy = [];
  links.forEach(function (a) {
    var h = a.getAttribute('href') || '';
    if (h.charAt(0) === '#' && h.length > 1) {
      var el = document.getElementById(h.slice(1));
      if (el) spy.push({ a: a, el: el });
    } else if (h && !/^(https?:|mailto:|tel:)/.test(h)) {
      var file = h.split('#')[0].split('/').pop();
      if (file && location.pathname.split('/').pop() === file) {
        a.classList.add('active'); a.setAttribute('aria-current', 'page');
      }
    }
  });
  if (spy.length) {
    var ticking = false;
    function update() {
      ticking = false;
      var probe = navH() + Math.min(window.innerHeight * 0.3, 220), best = null, bestTop = -Infinity;
      spy.forEach(function (s) {
        var t = s.el.getBoundingClientRect().top;
        if (t <= probe && t > bestTop) { bestTop = t; best = s.el; }
      });
      var atEnd = window.innerHeight + window.pageYOffset >= document.documentElement.scrollHeight - 4;
      if (atEnd) { var last = null, lt = -Infinity;
        spy.forEach(function (s) { var t = s.el.getBoundingClientRect().top; if (t > lt) { lt = t; last = s.el; } });
        best = last; }
      spy.forEach(function (s) {
        var on = s.el === best;
        s.a.classList.toggle('active', on);
        on ? s.a.setAttribute('aria-current', 'true') : s.a.removeAttribute('aria-current');
      });
    }
    function req() { if (!ticking) { ticking = true; requestAnimationFrame(update); } }
    window.addEventListener('scroll', req, { passive: true });
    window.addEventListener('resize', req); window.addEventListener('load', req);
    update();
  }

  /* 5. Keyboard users land on the section they jumped to */
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href^="#"]'); if (!a) return;
    var id = a.getAttribute('href'); if (id.length < 2) return;
    var t = document.getElementById(id.slice(1)); if (!t) return;
    if (!t.hasAttribute('tabindex')) t.setAttribute('tabindex', '-1');
    setTimeout(function () { try { t.focus({ preventScroll: true }); } catch (x) { t.focus(); } }, 0);
  });

  /* 6. Skip link */
  var target = document.getElementById('main') || document.getElementById('sv');
  if (target && !document.querySelector('.skip-link')) {
    var s = document.createElement('a'); s.className = 'skip-link'; s.href = '#' + target.id; s.textContent = 'Skip to content';
    document.body.insertBefore(s, document.body.firstChild);
  }
})();
