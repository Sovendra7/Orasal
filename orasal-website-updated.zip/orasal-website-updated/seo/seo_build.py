#!/usr/bin/env python3
"""Orasal SEO/GEO build. Idempotent: re-run any time. Edit SITE below if the domain differs."""
import re, json, base64, os, html as H, datetime
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
os.chdir(ROOT)
SITE = os.environ.get('ORASAL_SITE', 'https://www.orasal.com').rstrip('/')   # <-- CONFIRM your live domain
TODAY = datetime.date.today().isoformat()
EMAIL = 'hello.orasal@gmail.com'
ORG = SITE + '/#organization'
SOCIAL = ['https://www.linkedin.com/company/orasal', 'https://www.instagram.com/orasal.co',
          'https://www.facebook.com/share/14v2tnK9EgS/']
LOGO = SITE + '/assets/orasal-logo.png'
OGIMG = SITE + '/assets/og-image.png'
FOUNDERS = [('sovendra-yadav', 'Sovendra Yadav', 'Founder', 'Data science, artificial intelligence and full-stack web development',
             ['Artificial Intelligence', 'Data Science', 'Full-Stack Web Development']),
            ('nitin-yadav', 'Nitin Yadav', 'Co-Founder', 'Data analytics, artificial intelligence and digital growth',
             ['Data Analytics', 'Artificial Intelligence', 'Digital Marketing', 'Social Media Management'])]

# ---------------------------------------------------------------- page table
# slug: (title, description, breadcrumb, kind, service_name)
P = {
 'index': ('Orasal | AI Automation & Custom Software Development',
  'Orasal is an AI and digital solutions company in India. We build AI automation, AI chatbots, custom software, websites and web apps, plus growth marketing.', 'Home', 'WebPage', None),
 'services': ('Orasal Services: AI, Software, Web & Digital Growth',
  'Explore Orasal services: AI automation, AI chatbots and agents, custom software, website development, SEO, performance marketing, branding and social media.', 'Services', 'CollectionPage', None),
 'ai-automation': ('AI Automation Services & Workflow Automation | Orasal',
  'Orasal builds AI automation and intelligent workflow automation that removes manual work: lead follow-up, reporting, invoicing and CRM sync. Talk to our team.', 'AI Automation', 'WebPage', 'AI automation and business process automation'),
 'ai-chatbot-development': ('AI Chatbot & AI Agent Development Services | Orasal',
  'Custom AI chatbots and AI agents for websites, WhatsApp and Instagram that answer questions, qualify leads and book appointments 24/7. Built by Orasal.', 'AI Chatbots & Agents', 'WebPage', 'AI chatbot and AI agent development'),
 'custom-software-development': ('Custom Software & Web Application Development | Orasal',
  'Orasal develops custom business software, full-stack web applications, API integrations and AI-powered features tailored to your workflows. Free consultation.', 'Custom Software', 'WebPage', 'Custom software and web application development'),
 'website-development': ('Website Development Company in India | Orasal',
  'Custom, fast and SEO-ready business websites, web applications and eCommerce stores by Orasal. Mobile-first design, clean code and 30-day post-launch support.', 'Website Development', 'WebPage', 'Website development'),
 'plans': ('Website Development Pricing & Plans | Orasal',
  'Compare Orasal website development plans for business sites and eCommerce stores. Clear scope, delivery timelines and support included. Request a quote.', 'Plans & Pricing', 'WebPage', None),
 'seo': ('SEO Services: Technical, Content & Local SEO | Orasal',
  'Technical SEO, content strategy, link building and local search optimisation from Orasal for sustainable organic growth on Google and AI search.', 'SEO Optimization', 'WebPage', 'Search engine optimization'),
 'performance-marketing': ('Performance Marketing Services | Orasal',
  'Data-driven performance marketing by Orasal: Google Ads, Meta Ads and conversion optimisation with transparent tracking and reporting.', 'Performance Marketing', 'WebPage', 'Performance marketing'),
 'paid-ads': ('Google Ads & Meta Ads Management | Orasal',
  'Google Ads and Meta Ads management by Orasal: precise targeting, creative testing and clear reporting to lower cost per lead.', 'Paid Ads', 'WebPage', 'Paid advertising management'),
 'social-media': ('Social Media Management Services | Orasal',
  'Social media management by Orasal: Instagram, Facebook, LinkedIn and YouTube strategy, content creation, Reels and community management.', 'Social Media', 'WebPage', 'Social media management'),
 'branding': ('Branding & Creative: Logo and Brand Identity | Orasal',
  'Logo design, brand identity and visual systems by Orasal that make your business consistent, memorable and ready to grow.', 'Branding & Creative', 'WebPage', 'Branding and creative design'),
 'case-studies': ('Case Studies & Client Results | Orasal',
  'See how Orasal helped businesses grow with websites, performance marketing, branding and automation. Real project outcomes across India.', 'Case Studies', 'CollectionPage', None),
 'reviews': ('Client Reviews & Testimonials | Orasal',
  'Read what Orasal clients say about working with us on websites, marketing, branding and AI automation projects.', 'Reviews', 'CollectionPage', None),
 'about': ('About Orasal | AI, Software & Digital Growth Company',
  'Learn about Orasal: our story, values and mission to engineer intelligent growth with AI, software development and digital marketing for ambitious brands.', 'About', 'AboutPage', None),
 'founders': ('Founders: Sovendra Yadav & Nitin Yadav | Orasal',
  'Meet Sovendra Yadav (Founder) and Nitin Yadav (Co-Founder) of Orasal: computer science engineers in AI, data science and digital growth.', 'Founders', 'AboutPage', None),
 'contact': ('Contact Orasal | Book a Free Strategy Call',
  'Contact Orasal to discuss AI automation, custom software, websites or growth marketing. Book a free strategy call, email or WhatsApp us.', 'Contact', 'ContactPage', None),
 'privacy': ('Privacy Policy | Orasal', 'How Orasal collects, uses and protects personal information submitted through this website.', 'Privacy Policy', 'WebPage', None),
 'terms': ('Terms of Service | Orasal', 'The terms that apply when you use the Orasal website and engage Orasal for services.', 'Terms of Service', 'WebPage', None),
}
def url(slug): return SITE + '/' if slug == 'index' else SITE + '/pages/%s.html' % slug
def path(slug): return 'index.html' if slug == 'index' else 'pages/%s.html' % slug

# ---------------------------------------------------------------- FAQ content (visible AND in schema)
FAQ = {
'index': [
 ('What is Orasal?', 'Orasal is an AI and digital solutions company based in Bhopal, India. We build AI automation, AI chatbots and agents, custom software, websites and web applications, and run growth marketing such as SEO, paid ads and social media for businesses.'),
 ('What AI services does Orasal offer?', 'Orasal offers AI automation and workflow automation, AI chatbot and AI agent development for websites, WhatsApp and Instagram, and AI integration into existing business software through APIs.'),
 ('Does Orasal build custom software and websites?', 'Yes. Orasal develops business websites, eCommerce stores, full-stack web applications and custom business software, with API integrations and UI/UX design included where needed.'),
 ('Who founded Orasal?', 'Orasal was founded by Sovendra Yadav (Founder) and Nitin Yadav (Co-Founder), both computer science engineers working across artificial intelligence, data and web development.'),
 ('Where does Orasal work?', 'Orasal is based in Bhopal, Madhya Pradesh, India and works with clients across India and remotely worldwide.'),
 ('How do I get started with Orasal?', 'Book a free strategy call from the contact page, email hello.orasal@gmail.com or message us on WhatsApp. We review your goals and workflows, then propose scope, timeline and price.')],
'services': [
 ('What services does Orasal provide?', 'Orasal provides AI automation, AI chatbots and agents, custom software and web application development, website development, SEO, performance marketing, paid ads, social media management and branding.'),
 ('Is Orasal an AI automation company?', 'Yes. AI automation is a core service. We design workflow and business process automation that connects your tools and uses AI where judgement or language understanding is needed.'),
 ('Can I combine several services?', 'Yes. Many projects combine a website or web app with SEO, marketing and automation so that leads are captured, followed up and measured in one connected system.'),
 ('Do you work with small businesses and larger teams?', 'We work with startups, small businesses and growing teams. Scope and approach are set after we understand your workflows, tools and goals.'),
 ('How do I request a quote?', 'Use the contact page to book a free strategy call. We will ask about your goals and current setup, then send a clear scope, timeline and price.')],
'website-development': [
 ('How long does website development take?', 'Orasal builds business websites in as little as 7 business days, depending on scope, content readiness and feedback speed. Larger web applications and eCommerce builds are scoped individually.'),
 ('Are Orasal websites SEO-ready?', 'Yes. Sites ship with technical SEO foundations: fast loading, mobile-first layout, clean heading structure, meta tags and structured data.'),
 ('Can Orasal build an eCommerce website?', 'Yes. We build eCommerce stores with product catalogues, checkout and sales funnels, and can integrate payment, shipping and CRM tools through APIs.'),
 ('Do you build custom web applications, not just websites?', 'Yes. Beyond marketing websites we develop full-stack web applications and custom business software. See our custom software development service for details.'),
 ('Is support included after launch?', 'Yes. Orasal provides 30 days of post-launch support covering bug fixes, content updates and technical issues.')],
'ai-automation': [
 ('What is AI automation?', 'AI automation uses software workflows combined with artificial intelligence, such as language models and machine learning, to complete repetitive business tasks like lead follow-up, data entry, reporting and customer replies with little or no manual effort.'),
 ('Which processes should we automate first?', 'Start with high-volume, repetitive tasks that follow clear steps and cost the most staff time, such as lead capture and follow-up, invoice handling, report generation and data syncing between tools.'),
 ('How is AI automation different from workflow automation?', 'Workflow automation follows fixed rules. AI automation, also called intelligent automation, adds models that can read text, classify requests, extract data or draft replies, so it can handle tasks that need judgement.'),
 ('Can you integrate with our existing tools?', 'In most cases yes, through APIs, webhooks and standard integrations with CRMs, spreadsheets, messaging apps and accounting tools. We confirm what each tool supports during the workflow audit.'),
 ('How much does an AI automation project cost?', 'Cost depends on the number of workflows, the tools involved and how much AI is needed. We scope after a short workflow review and share a clear quote before work starts.')],
'ai-chatbot-development': [
 ('What is the difference between a chatbot and an AI agent?', 'A rule-based chatbot follows scripted flows. An AI chatbot uses a language model to understand free-form questions. An AI agent goes further and takes actions, such as booking an appointment, updating a CRM or sending a follow-up.'),
 ('Can the chatbot work on WhatsApp and Instagram?', 'Yes. Orasal builds bots for your website, WhatsApp and Instagram so customers get answers on the channel they already use.'),
 ('Can the chatbot answer questions about my business?', 'Yes. We ground the assistant in your own content, such as services, pricing information and FAQs, and set clear rules for what it should answer and when to hand over to a person.'),
 ('Will leads reach my team?', 'Yes. Chatbots can capture contact details and qualify enquiries, then pass them to your email, CRM or WhatsApp so nothing is missed.'),
 ('How long does an AI chatbot take to build?', 'A focused website or WhatsApp chatbot can be scoped and launched quickly, while multi-channel AI agents with integrations take longer. We confirm a timeline after the discovery call.')],
'custom-software-development': [
 ('What is custom software development?', 'Custom software development means designing and building software around your specific processes, instead of adapting your business to an off-the-shelf tool. Examples include internal tools, dashboards, portals and customer-facing web applications.'),
 ('When should I choose custom software over a ready-made tool?', 'Choose custom software when your workflow is unique, when you need to connect several systems, or when existing tools force manual workarounds that cost time every week.'),
 ('What does full-stack development include?', 'Full-stack development covers the user interface, the server-side logic, the database and the integrations, so one team delivers the whole working product.'),
 ('Can you integrate APIs and add AI features?', 'Yes. We integrate third-party and internal APIs, payment and messaging services, and add AI features such as assistants, document processing or smart search to existing products.'),
 ('How do projects start?', 'We begin with a free consultation to understand the problem, then define scope, milestones and timeline, and build in stages so you can review progress early.')],
}

# ---------------------------------------------------------------- related links (internal linking / topical cluster)
LABEL = {k: v[2] for k, v in P.items()}
REL = {
 'ai-automation': ['ai-chatbot-development', 'custom-software-development', 'website-development', 'services'],
 'ai-chatbot-development': ['ai-automation', 'custom-software-development', 'social-media', 'services'],
 'custom-software-development': ['ai-automation', 'ai-chatbot-development', 'website-development', 'services'],
 'website-development': ['custom-software-development', 'seo', 'plans', 'ai-automation'],
 'seo': ['website-development', 'performance-marketing', 'ai-chatbot-development', 'case-studies'],
 'performance-marketing': ['paid-ads', 'seo', 'ai-automation', 'case-studies'],
 'paid-ads': ['performance-marketing', 'website-development', 'ai-automation', 'case-studies'],
 'social-media': ['branding', 'ai-chatbot-development', 'performance-marketing', 'case-studies'],
 'branding': ['website-development', 'social-media', 'seo', 'case-studies'],
 'plans': ['website-development', 'custom-software-development', 'contact', 'services'],
}

CSS = """<style id="seo-css">
.seo-faq{max-width:860px;margin:0 auto}
.seo-faq details{background:var(--bg-card,rgba(255,255,255,.04));border:1px solid var(--border-card,rgba(255,255,255,.1));border-radius:18px;padding:0 22px;margin-bottom:12px}
.seo-faq summary{cursor:pointer;list-style:none;padding:18px 0;font-family:var(--font-head,inherit);font-weight:700;color:var(--text-primary,#fff);display:flex;justify-content:space-between;gap:16px;font-size:1rem}
.seo-faq summary::-webkit-details-marker{display:none}
.seo-faq summary::after{content:"+";color:var(--gold,#d4af37);font-size:1.3rem;line-height:1}
.seo-faq details[open] summary::after{content:"\\2013"}
.seo-faq p{color:var(--text-secondary,#aab);line-height:1.75;padding-bottom:18px;margin:0}
.seo-chips{display:flex;flex-wrap:wrap;gap:12px;justify-content:center;margin-top:8px}
.seo-chips a{display:inline-block;padding:10px 20px;border-radius:999px;border:1px solid var(--border-card,rgba(255,255,255,.12));color:var(--text-primary,#fff);text-decoration:none;font-family:var(--font-head,inherit);font-weight:600;font-size:.88rem}
.seo-chips a:hover,.seo-chips a:focus-visible{border-color:var(--gold,#d4af37);color:var(--gold,#d4af37)}
.seo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;margin-top:36px;text-align:left}
.seo-card{background:var(--bg-card,rgba(255,255,255,.04));border:1px solid var(--border-card,rgba(255,255,255,.1));border-radius:22px;padding:26px}
.seo-card h3{font-family:var(--font-head,inherit);font-size:1.05rem;margin-bottom:10px;color:var(--text-primary,#fff)}
.seo-card p{color:var(--text-secondary,#aab);line-height:1.7;font-size:.94rem;margin-bottom:12px}
.seo-card a{color:var(--gold,#d4af37);font-weight:700;text-decoration:none;font-size:.86rem}
.seo-lead{max-width:820px;margin:14px auto 0;color:var(--text-secondary,#aab);line-height:1.8;text-align:center}
.footcol h3{font-family:var(--font-head);font-size:.68rem;text-transform:uppercase;letter-spacing:.2em;color:var(--text-secondary);font-weight:700;margin-bottom:18px;transition:color .3s}
.ip-hero h2.ip-h1{font-family:var(--font-head);font-size:clamp(2rem,5.5vw,3.8rem);font-weight:900;line-height:1.08;letter-spacing:-.03em;color:var(--text-primary);margin-bottom:18px;max-width:760px}
</style>"""

# ---------------------------------------------------------------- helpers
def strip(t, key):
    return re.sub(r'\n?<!-- SEO:%s -->.*?<!-- /SEO:%s -->\n?' % (key, key), '\n', t, flags=re.S)
def wrap(key, body): return '<!-- SEO:%s -->\n%s\n<!-- /SEO:%s -->' % (key, body, key)
def ld(obj): return '<script type="application/ld+json">%s</script>' % json.dumps(obj, ensure_ascii=False, separators=(',', ':'))
def faq_html(slug, heading='Frequently Asked Questions', badge='FAQ', index_page=False):
    items = ''.join('<details><summary>%s</summary><p>%s</p></details>' % (H.escape(q), H.escape(a)) for q, a in FAQ[slug])
    pad = ' style="padding:90px 0;"' if index_page else ''
    sec = '<section id="faq" class="%s" aria-labelledby="faq-h"%s>' % ('' if index_page else 'ip-sec', pad)
    return (sec + '<div class="con"><div class="sh" style="text-align:center;margin-bottom:40px;">'
            '<div class="sbadge"><span class="tg">%s</span></div><h2 class="stitle" id="faq-h">%s</h2></div>'
            '<div class="seo-faq">%s</div></div></section>') % (badge, heading, items)
def related_html(slug):
    pre = '' if slug == 'index' else ''
    links = ''.join('<a href="%s.html">%s</a>' % (r, H.escape(LABEL[r])) for r in REL[slug])
    return ('<section class="ip-sec" aria-label="Related services"><div class="con" style="text-align:center;">'
            '<h2 class="stitle" style="font-size:clamp(1.4rem,3vw,2rem);">Related Services</h2>'
            '<div class="seo-chips">%s</div></div></section>') % links
def org_node():
    return {"@type": ["Organization", "ProfessionalService"], "@id": ORG, "name": "Orasal", "url": SITE + '/',
      "logo": {"@type": "ImageObject", "url": LOGO, "width": 512, "height": 512}, "image": OGIMG,
      "description": "Orasal is an AI and digital solutions company in India offering AI automation, AI chatbots and agents, custom software development, website development and growth marketing.",
      "slogan": "Intelligent digital growth", "email": EMAIL, "telephone": "+91-7409721774",
      "address": {"@type": "PostalAddress", "addressLocality": "Bhopal", "addressRegion": "Madhya Pradesh", "addressCountry": "IN"},
      "areaServed": [{"@type": "Country", "name": "India"}, {"@type": "Place", "name": "Worldwide (remote)"}],
      "openingHoursSpecification": {"@type": "OpeningHoursSpecification", "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], "opens": "09:00", "closes": "19:00"},
      "contactPoint": [{"@type": "ContactPoint", "contactType": "customer support", "telephone": "+91-7409721774", "email": EMAIL, "areaServed": "IN", "availableLanguage": ["English"]}],
      "founder": [{"@id": SITE + '/pages/founders.html#' + f[0]} for f in FOUNDERS], "sameAs": SOCIAL,
      "knowsAbout": ["AI automation", "AI chatbot development", "AI agents", "Generative AI", "Machine learning", "Workflow automation", "Business process automation",
                     "Custom software development", "Web application development", "Website development", "API integration", "eCommerce development", "UI/UX design", "SEO", "Performance marketing"],
      "hasOfferCatalog": {"@type": "OfferCatalog", "name": "Orasal services", "itemListElement": [
          {"@type": "Offer", "itemOffered": {"@type": "Service", "name": P[s][4], "url": url(s)}} for s in
          ['ai-automation', 'ai-chatbot-development', 'custom-software-development', 'website-development', 'seo', 'performance-marketing', 'paid-ads', 'social-media', 'branding']]}}
def schema_for(slug):
    title, desc, crumb, kind, svc = P[slug]; u = url(slug); g = []
    if slug == 'index':
        g.append(org_node())
        g.append({"@type": "WebSite", "@id": SITE + '/#website', "url": SITE + '/', "name": "Orasal", "inLanguage": "en-IN", "publisher": {"@id": ORG}})
    page = {"@type": kind, "@id": u + '#webpage', "url": u, "name": title, "description": desc, "inLanguage": "en-IN",
            "isPartOf": {"@id": SITE + '/#website'}, "about": {"@id": ORG}}
    if slug != 'index': page["breadcrumb"] = {"@id": u + '#breadcrumb'}
    if slug in ('about', 'founders'): page["mainEntity"] = {"@id": ORG}
    g.append(page)
    if slug != 'index':
        g.append({"@id": SITE + '/#website', "@type": "WebSite", "url": SITE + '/', "name": "Orasal", "publisher": {"@id": ORG}})
        g.append({"@type": "Organization", "@id": ORG, "name": "Orasal", "url": SITE + '/', "logo": LOGO, "sameAs": SOCIAL})
        items = [{"@type": "ListItem", "position": 1, "name": "Home", "item": SITE + '/'}]
        if slug != 'services' and slug in REL and slug not in ('plans',):
            items.append({"@type": "ListItem", "position": 2, "name": "Services", "item": url('services')})
        items.append({"@type": "ListItem", "position": len(items) + 1, "name": crumb, "item": u})
        g.append({"@type": "BreadcrumbList", "@id": u + '#breadcrumb', "itemListElement": items})
    if svc:
        g.append({"@type": "Service", "@id": u + '#service', "name": svc[0].upper() + svc[1:], "serviceType": svc, "url": u, "description": desc,
                  "provider": {"@id": ORG}, "areaServed": [{"@type": "Country", "name": "India"}, {"@type": "Place", "name": "Worldwide (remote)"}]})
    if slug == 'founders':
        for fid, nm, role, know, tags in FOUNDERS:
            g.append({"@type": "Person", "@id": u + '#' + fid, "name": nm, "jobTitle": role, "description": nm + ' is the ' + role + ' of Orasal, specialising in ' + know.lower() + '.',
                      "image": SITE + '/assets/%s.jpg' % fid, "worksFor": {"@id": ORG}, "knowsAbout": tags, "url": u})
    if slug in FAQ:
        g.append({"@type": "FAQPage", "@id": u + '#faq', "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in FAQ[slug]]})
    g = [x for x in g if x]
    # de-duplicate nodes by @id (keep first = richest)
    seen, out = set(), []
    for n in g:
        i = n.get('@id')
        if i and i in seen: continue
        if i: seen.add(i)
        out.append(n)
    return {"@context": "https://schema.org", "@graph": out}
def head_block(slug):
    title, desc, *_ = P[slug]; u = url(slug)
    e = lambda s: H.escape(s, quote=True)
    lines = ['<title>%s</title>' % H.escape(title), '<meta name="description" content="%s"/>' % e(desc),
      '<link rel="canonical" href="%s"/>' % u,
      '<meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"/>',
      '<link rel="alternate" hreflang="en-IN" href="%s"/>' % u, '<link rel="alternate" hreflang="x-default" href="%s"/>' % u,
      '<meta name="author" content="Orasal"/>', '<meta name="geo.region" content="IN-MP"/>', '<meta name="geo.placename" content="Bhopal"/>',
      '<meta property="og:type" content="website"/>', '<meta property="og:site_name" content="Orasal"/>', '<meta property="og:locale" content="en_IN"/>',
      '<meta property="og:title" content="%s"/>' % e(title), '<meta property="og:description" content="%s"/>' % e(desc), '<meta property="og:url" content="%s"/>' % u,
      '<meta property="og:image" content="%s"/>' % OGIMG, '<meta property="og:image:width" content="1200"/>', '<meta property="og:image:height" content="630"/>',
      '<meta property="og:image:alt" content="Orasal - AI automation, software and digital growth company"/>',
      '<meta name="twitter:card" content="summary_large_image"/>', '<meta name="twitter:title" content="%s"/>' % e(title),
      '<meta name="twitter:description" content="%s"/>' % e(desc), '<meta name="twitter:image" content="%s"/>' % OGIMG,
      ld(schema_for(slug))]
    if slug in FAQ or True: lines.append(CSS)
    return wrap('HEAD', '\n'.join(lines))

# ---------------------------------------------------------------- new pages
NEW = {
'ai-automation': dict(badge='AI Automation Services', h1a='AI Automation Services', h1b='That Remove Manual Work',
  lead='Orasal is an AI automation company that designs workflow and business process automation for growing teams. We connect your tools, data and AI models so repetitive tasks run on their own.',
  s1=('What We Automate', 'Workflows That Save Hours Every Week', 'Practical automation built around the work your team repeats most.',
      [('&#128236;', 'Lead Capture & Follow-Up', 'Route enquiries from forms, WhatsApp and ads into your CRM and trigger instant, personalised follow-ups.'),
       ('&#128172;', 'Customer Replies & Triage', 'Classify incoming requests, draft replies and escalate the cases that need a person.'),
       ('&#128202;', 'Reporting & Dashboards', 'Pull data from ads, sales and finance tools into automatic reports so nobody compiles spreadsheets by hand.'),
       ('&#129534;', 'Invoicing & Finance Ops', 'Generate invoices, send reminders and reconcile entries with fewer manual errors.'),
       ('&#128260;', 'CRM & Data Sync', 'Keep systems consistent with API integration and webhooks between the tools you already use.'),
       ('&#129302;', 'Document & Data Processing', 'Use AI and machine learning to read, extract and categorise information from emails, forms and files.')]),
  s2=('How It Works', 'From Workflow Audit to Live Automation',
      [('01', 'Audit', 'We map how work flows today and find the tasks that cost the most time.'),
       ('02', 'Design', 'We use AI where judgement is needed and simple rules where they are enough.'),
       ('03', 'Build & Integrate', 'We connect your tools through APIs and test with real examples.'),
       ('04', 'Monitor & Improve', 'We track results, fix edge cases and extend what works.')]),
  s3=('Key Terms', 'Workflow, Intelligent and Business Process Automation',
      [('Workflow automation', 'Fixed, rule-based steps that move information between tools, for example sending a form entry to a CRM.'),
       ('Intelligent automation', 'Workflow automation plus AI models that read text, classify requests or draft responses, so it can handle judgement tasks.'),
       ('Business process automation', 'End-to-end automation of a whole process across teams, such as lead to quote to invoice.')]),
  svc='AI Automation'),
'ai-chatbot-development': dict(badge='AI Chatbots & Agents', h1a='AI Chatbot & AI Agent Development', h1b='For Web, WhatsApp & Instagram',
  lead='Orasal builds custom AI chatbots and AI agents using generative AI, so your business answers customers instantly, qualifies leads and books appointments around the clock.',
  s1=('What We Build', 'Assistants That Work Where Your Customers Are', 'Each assistant is trained on your own content and connected to your workflow.',
      [('&#128187;', 'Website AI Chatbots', 'On-site assistants that answer questions about your services and guide visitors to the right action.'),
       ('&#128241;', 'WhatsApp Chatbots', 'Automated conversations on the channel most customers already use, with handover to your team.'),
       ('&#128248;', 'Instagram DM Bots', 'Reply to comments and messages, capture leads and keep conversations moving.'),
       ('&#129302;', 'AI Agents', 'Assistants that take action: book appointments, update your CRM and trigger follow-ups.'),
       ('&#127919;', 'Lead Qualification Bots', 'Ask the right questions, score enquiries and pass qualified leads straight to your inbox or CRM.'),
       ('&#128218;', 'Knowledge-Base Assistants', 'Answer from your documents, FAQs and policies with clear limits on what the bot should say.')]),
  s2=('How It Works', 'From Discovery to a Live Assistant',
      [('01', 'Discover', 'We define the questions, tasks and tone the assistant must handle.'),
       ('02', 'Build', 'We connect your content and tools, and design the conversation flow.'),
       ('03', 'Test', 'We test real customer questions and set rules for human handover.'),
       ('04', 'Launch & Refine', 'We go live, review conversations and improve answers over time.')]),
  s3=('Key Terms', 'Chatbot, Generative AI Assistant and AI Agent',
      [('Rule-based chatbot', 'Follows scripted menus and flows. Predictable and simple, but limited to what was planned.'),
       ('Generative AI assistant', 'Uses a language model to understand free-form questions and reply in natural language, grounded in your content.'),
       ('AI agent', 'A generative AI assistant that can also take actions in your tools, such as booking, updating records or sending messages.')]),
  svc='AI Chatbots'),
'custom-software-development': dict(badge='Custom Software Development', h1a='Custom Software & Web Application', h1b='Development Built Around You',
  lead='Orasal is a software development company building custom business software, full-stack web applications and integrations designed around how your business actually works.',
  s1=('What We Build', 'Software Shaped by Your Workflow', 'From internal tools to customer-facing platforms, delivered in clear stages.',
      [('&#128736;', 'Custom Business Software', 'Internal tools, portals and dashboards that replace spreadsheets and manual workarounds.'),
       ('&#127760;', 'Web Application Development', 'Full-stack web apps covering interface, server logic, database and deployment.'),
       ('&#128279;', 'API & AI Integration', 'Connect payment, messaging, CRM and other systems, and add AI features to existing products.'),
       ('&#128717;', 'eCommerce Development', 'Online stores with catalogues, checkout and integrations that fit your operations.'),
       ('&#127912;', 'UI/UX Development', 'Clear, accessible interfaces designed with your users and tested on real devices.'),
       ('&#128640;', 'Digital Transformation', 'Move manual and paper-based processes onto reliable software step by step.')]),
  s2=('How It Works', 'A Staged Delivery Process',
      [('01', 'Consult', 'We learn the problem, users and constraints.'),
       ('02', 'Scope', 'We agree features, milestones, timeline and price.'),
       ('03', 'Build', 'We develop in stages so you can review early and often.'),
       ('04', 'Launch & Support', 'We deploy, train your team and support the release.')]),
  s3=('Key Terms', 'Custom Software, Full-Stack and Integration',
      [('Custom software', 'Software designed for your specific processes, rather than adapting your business to a generic tool.'),
       ('Full-stack development', 'One team delivering the interface, backend logic, database and integrations of a complete product.'),
       ('API integration', 'Connecting separate systems so they exchange data automatically instead of by manual copy and paste.')]),
  svc='Custom Software'),
}
def new_body(slug):
    d = NEW[slug]; b1, t1, sub1, cards = d['s1']; b2, t2, steps = d['s2']; b3, t3, terms = d['s3']
    cardh = ''.join('<div class="pc"><span class="em" aria-hidden="true">%s</span><h3>%s</h3><p>%s</p></div>' % (e, H.escape(t).replace('&amp;', '&amp;'), H.escape(p)) for e, t, p in cards)
    steph = ''.join('<div class="pc"><div class="stat-num">%s</div><h3>%s</h3><p>%s</p></div>' % (n, H.escape(t), H.escape(p)) for n, t, p in steps)
    termh = ''.join('<div class="pc"><h3>%s</h3><p>%s</p></div>' % (H.escape(t), H.escape(p)) for t, p in terms)
    hero = ('<section class="ip-hero" aria-labelledby="ph"><div class="hgrid" aria-hidden="true"></div><div class="con">'
      '<div class="ip-badge"><span>&#10022; %s</span></div><h1 id="ph">%s<br/><span class="tg">%s</span></h1><p>%s</p>'
      '<div class="hctas"><a href="contact.html" class="pbtn">Book a Free Consultation</a><a href="services.html" class="obtn">All Services</a></div></div></section>') % (
      H.escape(d['badge']), H.escape(d['h1a']), H.escape(d['h1b']), H.escape(d['lead']))
    def sec(badge, title, sub, inner, grid):
        return ('<section class="ip-sec"><div class="con"><div class="sh" style="text-align:center;margin-bottom:48px;"><div class="sbadge"><span class="tg">%s</span></div>'
                '<h2 class="stitle">%s</h2>%s</div><div class="%s">%s</div></div></section>') % (badge, H.escape(title), ('<p class="ssub">%s</p>' % H.escape(sub)) if sub else '', grid, inner)
    return (hero + sec(b1, t1, sub1, cardh, 'g3') + '<div class="hdiv"></div>' + sec(b2, t2, '', steph, 'g4') + '<div class="hdiv"></div>'
            + sec(b3, t3, '', termh, 'g3') + '<div class="hdiv"></div>' + wrap('FAQ', faq_html(slug)) + wrap('REL', related_html(slug))
            + ('<section class="cta-strip"><div class="con"><h2>Ready to Talk About %s?</h2><p>Book a free call. We will review your goals and tools, then propose scope, timeline and price.</p>'
               '<div class="btn-row"><a href="contact.html" class="pbtn">Get a Free Quote</a><a href="https://wa.me/917409721774" class="obtn">WhatsApp Us</a></div></div></section>\n') % H.escape(d['svc']))

# ---------------------------------------------------------------- run
def prep_assets():
    h = open('index.html', encoding='utf8').read()
    # extract embedded 96px logo once, then point everything at real files (smaller, cacheable HTML)
    m = re.search(r'alt=\\?"Orasal Home\\?">\s*<img src=\\?"(data:image/png;base64,[^"\\]+)', h) or re.search(r'class=\\?"nlogo\\?"[^>]*>\s*<img src=\\?"(data:image/png;base64,[^"\\]+)', h)
    if not os.path.exists('assets/orasal-logo-96.png'):
        from PIL import Image
        img = Image.open('assets/orasal-logo.png').convert('RGBA').resize((192, 192), Image.LANCZOS)
        img.save('assets/orasal-logo-96.png', optimize=True)
    if not os.path.exists('assets/og-image.png'):
        from PIL import Image, ImageDraw, ImageFont
        W, Hh = 1200, 630
        im = Image.new('RGB', (W, Hh), (8, 8, 13)); dr = ImageDraw.Draw(im)
        for i in range(Hh): dr.line([(0, i), (W, i)], fill=(8 + i // 40, 10 + i // 30, 22 + i // 12))
        lg = Image.open('assets/orasal-logo.png').convert('RGBA').resize((220, 220), Image.LANCZOS); im.paste(lg, (90, 205), lg)
        def f(sz, bold=True):
            for p in ['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf']:
                if os.path.exists(p): return ImageFont.truetype(p, sz)
            return ImageFont.load_default()
        dr.text((350, 200), 'Orasal', font=f(96), fill=(255, 255, 255))
        dr.text((352, 322), 'AI Automation, Custom Software', font=f(38), fill=(96, 165, 250))
        dr.text((352, 372), '& Digital Growth', font=f(38), fill=(96, 165, 250))
        im.save('assets/og-image.png', optimize=True)
    n = 0
    def rep(mm):
        nonlocal n
        raw = mm.group(2).replace('\\', ''); size = len(base64.b64decode(raw + '=' * (-len(raw) % 4)))
        tgt = {8646: 'assets/favicon.png', 44171: 'assets/apple-touch-icon.png', 78403: 'assets/sovendra-yadav.jpg', 68158: 'assets/nitin-yadav.jpg', 49156: 'assets/orasal-logo-96.png'}.get(size)
        if not tgt: return mm.group(0)
        n += 1; return tgt
    h2 = re.sub(r'(?<=[="\'])(data:image/(?:png|jpe?g);base64,([A-Za-z0-9+/=\\]+))', lambda mm: rep(type('M', (), {'group': lambda s, i=0: mm.group(i) if i != 2 else mm.group(2)})()), h)
    open('index.html', 'w', encoding='utf8').write(h2)
    return n

def patch_common(t, slug, in_pages):
    pre = '' if in_pages else 'pages/'
    t = re.sub(r'<html lang="en"', '<html lang="en-IN"', t, count=1)
    t = strip(t, 'HEAD')
    t = re.sub(r'<title>.*?</title>\s*', '', t, count=1, flags=re.S)
    t = re.sub(r'<meta name="description"[^>]*/?>\s*', '', t, count=1)
    t = t.replace('</head>', head_block(slug) + '\n</head>', 1)
    t = re.sub(r'<div class=(\\?)"footcol\1><h4>(.*?)</h4>', lambda m: '<div class="footcol"><h3>' + m.group(2) + '</h3>', t) if False else re.sub(r'<div class="footcol"><h4>(.*?)</h4>', r'<div class="footcol"><h3>\1</h3>', t)
    # footer cluster links
    if '<li><a href="%sai-automation.html">AI Automation</a></li>' % pre not in t:
        anchor = re.search(r'(<li><a href="(?:pages/)?seo\.html">SEO Optimization</a></li>)', t)
        if anchor:
            add = ''.join('\n        <li><a href="%s%s.html">%s</a></li>' % (pre, s, l) for s, l in
                          [('ai-automation', 'AI Automation'), ('ai-chatbot-development', 'AI Chatbots &amp; Agents'), ('custom-software-development', 'Custom Software')])
            t = t.replace(anchor.group(1), anchor.group(1) + add, 1)
    if in_pages:  # logo: serve 192px file instead of 512px for 44-96px slots; alt text; founder image dims
        t = t.replace('<img src="../assets/orasal-logo.png" alt="Orasal Logo"', '<img src="../assets/orasal-logo-96.png" alt="Orasal logo" decoding="async"')
        t = t.replace('<img src="../assets/orasal-logo.png" alt="Orasal"', '<img src="../assets/orasal-logo-96.png" alt="Orasal logo" decoding="async" loading="lazy"')
        t = re.sub(r'(<img src="\.\./assets/(?:sovendra|nitin)-yadav\.jpg" alt="[^"]+") loading="lazy"/>', r'\1 width="720" height="900" loading="lazy" decoding="async"/>', t)
    return t

def build():
    n = prep_assets()
    tpl = open('pages/website-development.html', encoding='utf8').read()
    for slug in NEW:   # create new pages from the existing inner-page template
        t = strip(strip(tpl, 'FAQ'), 'REL')
        a = t.index('<!-- PAGE CONTENT -->'); b = t.index('<!-- SHARED FOOTER')
        t = t[:a] + '<!-- PAGE CONTENT -->\n' + new_body(slug) + '\n  ' + t[b:]
        t = t.replace('../index.html#wb', '../index.html#wb')
        open(path(slug), 'w', encoding='utf8').write(patch_common(t, slug, True))
    for slug in P:
        if slug in NEW: continue
        t = open(path(slug), encoding='utf8').read(); inp = slug != 'index'
        t = strip(strip(strip(t, 'FAQ'), 'REL'), 'GLANCE')
        t = patch_common(t, slug, inp)
        if slug in REL:
            blk = wrap('REL', related_html(slug)); fq = wrap('FAQ', faq_html(slug)) if slug in FAQ else ''
            m = re.search(r'\s*<section class="cta-strip', t) or re.search(r'<!-- SHARED FOOTER', t)
            t = t[:m.start()] + '\n' + fq + '\n' + blk + '\n' + t[m.start():]
        if slug == 'services':
            t = t.replace('7 Services. One Goal:', '10 Services. One Goal:')
            if 'ai-automation.html' not in t.split('<h3>Funnel')[1].split('</section>')[0]:
                i = t.index('<h3>Funnel &amp; Automation</h3>'); j = t.index('</div>', t.index('</a>', i)) + 6
                cards = ''.join('\n      <div class="pc"><span class="em" aria-hidden="true">%s</span><h3>%s</h3><p style="margin-bottom:14px;">%s</p><a href="%s.html" style="color:var(--gold);font-size:.84rem;font-weight:700;text-decoration:none;font-family:var(--font-head);">Learn More &#8594;</a></div>' % c
                                for c in [('&#129302;', 'AI Automation', 'Workflow and business process automation that removes repetitive work.', 'ai-automation'),
                                          ('&#128172;', 'AI Chatbots &amp; Agents', 'Generative AI chatbots and agents for web, WhatsApp and Instagram.', 'ai-chatbot-development'),
                                          ('&#128736;', 'Custom Software', 'Custom business software, web apps and API integrations.', 'custom-software-development')])
                t = t[:j] + cards + t[j:]
        if slug == 'index':
            # single H1: demote the founders overlay heading, keep its look
            t = re.sub(r'<h1 id="ph" class="fu d1">(The Minds Behind.*?)</h1>', lambda m: '<h2 id="ph" class="fu d1 ip-h1">' + m.group(1) + '</h2>', t, flags=re.S)
            # crawlable service links on the homepage cards
            for label, s in [('Website Development', 'website-development'), ('Performance Marketing', 'performance-marketing'), ('Social Media Management', 'social-media'),
                             ('Paid Ads (Google & Meta)', 'paid-ads'), ('Branding & Creative', 'branding'), ('SEO Optimization', 'seo'), ('AI Automation', 'ai-automation'), ('AI Chatbots &amp; Bots', 'ai-chatbot-development')]:
                i = t.find('<h3>%s</h3>' % label)
                if i < 0: continue
                k = t.index('<div class="sarrow"', i); k2 = t.index('</div>', k)
                seg = t[k:k2]
                if '<a ' in seg: continue
                m = re.match(r'(<div class="sarrow"[^>]*>)(.*)', seg, re.S)
                t = t[:k] + m.group(1) + '<a href="pages/%s.html" style="color:inherit;text-decoration:none;">%s</a>' % (s, m.group(2)) + t[k2:]
            glance = ('<section id="about-orasal" aria-labelledby="ao-h" style="padding:90px 0;"><div class="con" style="text-align:center;">'
              '<div class="sh"><div class="sbadge"><span class="tg">About Orasal</span></div>'
              '<h2 class="stitle" id="ao-h">AI, Automation &amp; Software Solutions for Growing Businesses</h2></div>'
              '<p class="seo-lead">Orasal is an AI and digital solutions company based in Bhopal, India, founded by computer science engineers Sovendra Yadav and Nitin Yadav. '
              'We combine AI automation, chatbot and AI agent development, custom software and website development with SEO and performance marketing, so one team can build, connect and grow your digital operations.</p>'
              '<div class="seo-grid">'
              '<div class="seo-card"><h3>AI Automation Services</h3><p>Workflow, intelligent and business process automation that removes repetitive manual work.</p><a href="pages/ai-automation.html">AI automation &#8594;</a></div>'
              '<div class="seo-card"><h3>AI Chatbots &amp; AI Agents</h3><p>Generative AI assistants for your website, WhatsApp and Instagram that answer, qualify and book.</p><a href="pages/ai-chatbot-development.html">AI chatbot development &#8594;</a></div>'
              '<div class="seo-card"><h3>Custom Software &amp; Web Apps</h3><p>Full-stack web applications, business software and API integrations built around your workflow.</p><a href="pages/custom-software-development.html">Custom software &#8594;</a></div>'
              '<div class="seo-card"><h3>Website Development</h3><p>Fast, SEO-ready business websites and eCommerce stores with 30 days of post-launch support.</p><a href="pages/website-development.html">Website development &#8594;</a></div>'
              '</div></div></section>')
            fq = faq_html('index', heading='Questions About Orasal, AI Automation &amp; Development', index_page=True)
            m = re.search(r'<section id="ctab"', t)
            t = t[:m.start()] + wrap('GLANCE', glance) + '\n' + wrap('FAQ', fq) + '\n\n' + t[m.start():]
        open(path(slug), 'w', encoding='utf8').write(t)
    # sitemap, robots, llms.txt
    urls = ['index'] + [s for s in P if s != 'index']
    pri = {'index': '1.0', 'services': '0.9', 'ai-automation': '0.9', 'ai-chatbot-development': '0.9', 'custom-software-development': '0.9', 'website-development': '0.9', 'privacy': '0.2', 'terms': '0.2'}
    sm = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + ''.join(
        '  <url><loc>%s</loc><lastmod>%s</lastmod><priority>%s</priority></url>\n' % (url(s), TODAY, pri.get(s, '0.7')) for s in urls) + '</urlset>\n'
    open('sitemap.xml', 'w').write(sm)
    bots = ['GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-User', 'Claude-SearchBot', 'anthropic-ai', 'PerplexityBot', 'Perplexity-User', 'Google-Extended', 'Applebot-Extended', 'Bingbot', 'Googlebot']
    open('robots.txt', 'w').write('# Orasal - all search engines and AI crawlers are welcome\nUser-agent: *\nAllow: /\n\n' + ''.join('User-agent: %s\nAllow: /\n\n' % b for b in bots)
                                   + 'Sitemap: %s/sitemap.xml\n' % SITE)
    L = ['# Orasal', '', '> Orasal is an AI and digital solutions company based in Bhopal, Madhya Pradesh, India. It builds AI automation, AI chatbots and agents, custom software, websites and web applications, and provides SEO and performance marketing. Founded by Sovendra Yadav (Founder) and Nitin Yadav (Co-Founder). Serves clients across India and remotely worldwide.', '', '## Core services']
    for s in ['ai-automation', 'ai-chatbot-development', 'custom-software-development', 'website-development']:
        L.append('- [%s](%s): %s' % (LABEL[s], url(s), P[s][1]))
    L += ['', '## Growth marketing']
    for s in ['seo', 'performance-marketing', 'paid-ads', 'social-media', 'branding']:
        L.append('- [%s](%s): %s' % (LABEL[s], url(s), P[s][1]))
    L += ['', '## Company', '- [About](%s)' % url('about'), '- [Founders](%s)' % url('founders'), '- [Case studies](%s)' % url('case-studies'), '- [Reviews](%s)' % url('reviews'), '- [Plans & pricing](%s)' % url('plans'),
          '- [Contact](%s)' % url('contact'), '', '## Contact', '- Email: ' + EMAIL, '- Phone / WhatsApp: +91 7409721774', '- Hours: Monday-Saturday, 9 AM-7 PM IST', '- Location: Bhopal, Madhya Pradesh, India']
    open('llms.txt', 'w').write('\n'.join(L) + '\n')
    print('replaced embedded images:', n, '| pages built:', len(P), '| site:', SITE)
build()
