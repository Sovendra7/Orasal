#!/usr/bin/env python3
"""Static SEO audit. Run: python3 seo/seo_audit.py  (exit code 1 if critical issues)"""
import re, json, os, glob, sys
from collections import Counter
os.chdir(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
files = ['index.html'] + sorted(glob.glob('pages/*.html'))
crit, warn = [], []
titles, descs = Counter(), Counter()
sm = open('sitemap.xml').read() if os.path.exists('sitemap.xml') else ''
for f in files:
    t = open(f, encoding='utf8').read()
    head = t.split('</head>')[0]
    vis = re.sub(r'<script.*?</script>|<style.*?</style>', '', t, flags=re.S)
    ti = re.findall(r'<title>(.*?)</title>', head, re.S)
    de = re.findall(r'<meta name="description" content="([^"]*)"', head)
    if len(ti) != 1: crit.append((f, 'title count %d' % len(ti)))
    elif not 25 <= len(ti[0]) <= 65: warn.append((f, 'title length %d' % len(ti[0])))
    if len(de) != 1: crit.append((f, 'meta description count %d' % len(de)))
    elif not 70 <= len(de[0]) <= 165: warn.append((f, 'description length %d' % len(de[0])))
    titles[ti[0] if ti else f] += 1; descs[de[0] if de else f] += 1
    can = re.findall(r'<link rel="canonical" href="([^"]+)"', head)
    if len(can) != 1: crit.append((f, 'canonical count %d' % len(can)))
    if 'property="og:title"' not in head or 'twitter:card' not in head: crit.append((f, 'missing OG/Twitter'))
    if 'name="viewport"' not in head: crit.append((f, 'no viewport'))
    if '<html lang=' not in t[:200]: crit.append((f, 'no html lang'))
    h1 = re.findall(r'<h1[ >]', vis)
    if len(h1) != 1: crit.append((f, 'h1 count %d' % len(h1)))
    # heading order
    lv = [int(x) for x in re.findall(r'<h([1-6])[ >]', vis)]
    for a, b in zip(lv, lv[1:]):
        if b - a > 1: warn.append((f, 'heading jump h%d->h%d' % (a, b))); break
    # JSON-LD
    blocks = re.findall(r'<script type="application/ld\+json">(.*?)</script>', t, re.S)
    if not blocks: crit.append((f, 'no JSON-LD'))
    types = []
    for b in blocks:
        try:
            j = json.loads(b); types += [n.get('@type') for n in j['@graph']]
        except Exception as e: crit.append((f, 'invalid JSON-LD: %s' % e))
    # images
    for im in re.findall(r'<img\b[^>]*>', vis):
        if 'alt=' not in im: crit.append((f, 'img without alt'))
        if 'width=' not in im and 'height=' not in im: warn.append((f, 'img without dimensions'))
        if 'data:image' in im: warn.append((f, 'inline base64 image'))
    # internal links
    base = os.path.dirname(f)
    for href in re.findall(r'<a\b[^>]*href="([^"#?][^"]*)"', vis):
        if re.match(r'(https?:|mailto:|tel:|javascript:)', href): continue
        p = os.path.normpath(os.path.join(base, href.split('#')[0]))
        if not os.path.exists(p): crit.append((f, 'broken link ' + href))
    if f != 'index.html' and 'BreadcrumbList' not in types: crit.append((f, 'no breadcrumb schema'))
    if 'FAQPage' in types and 'seo-faq' not in t: crit.append((f, 'FAQ schema without visible FAQ'))
    n_in = len([h for h in re.findall(r'<a\b[^>]*href="([^"]+)"', vis) if not h.startswith(('http', 'mailto', 'tel', '#', 'javascript'))])
    print('%-42s title=%-3s desc=%-3s h1=%d jsonld=%-2d ldtypes=%s links=%d' % (f, len(ti[0]) if ti else 0, len(de[0]) if de else 0, len(h1), len(blocks), ','.join(sorted(set(str(x) for x in types if x)))[:60], n_in))
for k, v in titles.items():
    if v > 1: crit.append(('site', 'duplicate title: ' + k))
for k, v in descs.items():
    if v > 1: crit.append(('site', 'duplicate description: ' + k[:50]))
for f in files:
    loc = ('/' if f == 'index.html' else '/' + f)
    if loc not in sm and f != 'index.html': crit.append((f, 'missing from sitemap'))
for fn in ['robots.txt', 'sitemap.xml', 'llms.txt', 'assets/og-image.png']:
    if not os.path.exists(fn): crit.append(('site', 'missing ' + fn))
print('\nCRITICAL: %d' % len(crit)); [print('  -', *c) for c in crit]
print('WARNINGS: %d' % len(warn)); [print('  -', *c) for c in warn]
sys.exit(1 if crit else 0)
