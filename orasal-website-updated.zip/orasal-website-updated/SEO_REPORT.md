# Orasal SEO / GEO implementation report

Re-run anytime: `python3 seo/seo_build.py` (rebuild) then `python3 seo/seo_audit.py` (audit).
**Set your real domain first:** `ORASAL_SITE=https://yourdomain.com python3 seo/seo_build.py` (default assumed: https://www.orasal.com).

## Implemented
- Unique title, meta description, canonical, robots (max-snippet/max-image-preview), hreflang en-IN, Open Graph, Twitter cards on all 18 pages (+3 new = 19 URLs incl. home).
- JSON-LD (@graph): Organization + ProfessionalService (address, hours, contact, founders, offer catalog, sameAs), WebSite, WebPage types, BreadcrumbList, Service, Person (founders), FAQPage (only where a matching visible FAQ exists).
- 3 new topical pages: AI automation, AI chatbot & agent development, custom software / web application development.
- Visible FAQs (6 pages) + "About Orasal" entity block on home; related-services internal links; footer cluster links; crawlable links on homepage service cards; services page now lists 10 services.
- robots.txt (all search + AI crawlers allowed), sitemap.xml (19 URLs), llms.txt, 1200x630 social image.
- Performance: index.html 1.44 MB -> 0.88 MB (embedded base64 images moved to cached files); logo served at 192px instead of 512px (260 KB -> 50 KB); founder image dimensions added (CLS).
- Fixes: duplicate H1 on home, footer heading levels, html lang en-IN, short/duplicate titles.

## Needs your input (not changed)
1. Confirm domain (canonical/sitemap/schema all use SITE).
2. Pricing conflict: home/plans show Rs.9,999, website-development page says Rs.7,999.
3. Unverifiable claims on page ("120+ projects", "5x ROAS", "312% growth", "Fastest in industry") - verify or soften; deliberately NOT put in schema (no AggregateRating).
4. Add full street address, founding year, GBP listing, LinkedIn/Instagram bios matching the entity description.

## Remaining opportunities
Blog/guides (e.g. "AI automation for small business"), case-study detail pages, real client reviews with Review schema, Google Business Profile, Search Console/Bing Webmaster submission, serve 404/redirects (`/pages/x.html` -> clean URLs), HTTP caching + compression, `<main>` landmark (skipped: changes CSS nth-child section backgrounds), defer large inline scripts.
