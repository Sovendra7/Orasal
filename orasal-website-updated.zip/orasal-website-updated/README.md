# Orasal website

Open `index.html` in a browser (or serve the folder with any static server).

## Motion layer
- `assets/motion.css` + `assets/motion.js` add smooth, interaction-driven UI motion:
  springy hover/press on buttons and cards, 3D tilt with cursor glow, a sliding nav pill,
  and a springy mobile menu with staggered items.
- It is dependency-free (own spring engine), so there is nothing to install.
  It respects `prefers-reduced-motion`.
- Looping/ambient animation (particles, floating orbs, custom cursor, auto-advancing slider, count-up) is turned off.
- To use the real Motion (Framer Motion) or Rive libraries instead, install them with npm
  and replace the spring calls in `assets/motion.js` (`Mo.go(...)`); Rive also needs a `.riv` file made in the Rive editor.

## Updates
- New Orasal logo (`assets/orasal-logo.png`, favicon and touch icon) applied to every page.
- Contact form sends to hello.orasal@gmail.com via FormSubmit (confirm the activation email once); falls back to the visitor's email app.
- All animations are turned off.
- Navbar upgrade (`assets/nav.js`, `assets/nav.css`): active-section highlight while scrolling, correct anchor offset under the fixed bar, accessible mobile menu (focus handling, Escape, no stuck scroll-lock on resize), circular theme button with live labels, skip link.
- Fixed: contact, privacy and terms pages were cut off in the upload (no scripts/closing tags) - repaired. Inner pages now have a working mobile menu, and the shared script no longer errors on pages without the testimonial slider.

## Hero update
- Hero right side: 3D laptop mockup + 4 floating service cards + blue orbit/ribbon canvas (`#hvOrbit`, inline in `index.html`, styles in `#hv-lap-css`).
- Old single 'Now Accepting Clients' card hidden on desktop (it overlapped the laptop).
